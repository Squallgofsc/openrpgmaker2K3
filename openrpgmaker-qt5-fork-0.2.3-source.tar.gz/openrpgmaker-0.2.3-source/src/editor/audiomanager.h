#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include <QObject>
#include <QMap>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

class QString;
class QTimer;

class AudioManager : public QObject
{
	Q_OBJECT
	public:
		struct SoundEffectInfo
		{
			QString location;
			float volume;
			float panning;
			float speed;
			int numLoops;
			int sfxID;
			bool retainPitch;
		};
		struct MusicInfo
		{
			QString location;
			float volume;
			float panning;
			float speed;
			int fadeInTime;
			bool retainPitch;
		};
		AudioManager();
		~AudioManager();
		static void initializeAudioManager();
		static void shutdownAudioManager();
		static unsigned int loadSoundEffect(QString location);
		static void freeSoundEffect(unsigned int sfxID);
		static void playSoundEffect(unsigned int sfxID, float volume, float panning, float speed, bool retainPitch, int numLoops, bool freeWhenFinished=false);
		static void stopSoundEffect(unsigned int sfxID);
		static void loadMusicFile(QString location);
		static void freeMusicFile();
		static void playMusic(int fadeInTime, float volume, float panning, float speed, bool retainPitch, bool freeWhenFinished=false);
		static void stopMusic();
		static void stopAllSoundEffects();
		static bool isSoundEffectPlaying(unsigned int sfxID);
		static bool isSoundEffectPlaying();
		static bool isMusicPlaying();
		static float getMusicPlaySpeed();
		static unsigned int getMusicPosition();
		static unsigned int getSoundEffectLength(unsigned int sfxID);
		static unsigned int getMusicLength();
		static bool isAudioEnabled();
	signals:
		void soundEffectPositionUpdated(unsigned int sfxID, unsigned int currentPosition);
		void soundEffectStopped(unsigned int sfxID);
		void musicPositionUpdated(unsigned int currentPosition);
		void musicStopped();
	private slots:
		void updateSystem();
	private:
		static void speedEffectCallback(int chan, void *stream, int len, void *udata);
		static void speedEffectDone(int chan, void *udata);

		struct SfxRuntime
		{
			Mix_Chunk *chunk;
			QString location;
			int channel;
			float speed;
			bool retainPitch;
			bool freeWhenFinished;
			unsigned int samplesPlayed;
			double resamplePos;
		};

		static bool checkError(QString errorMessage);
		static QTimer *timer;
		static QMap<unsigned int, SfxRuntime*> sfx;
		static QMap<unsigned int, SfxRuntime*>::iterator sfxIter;
		static QMap<int, unsigned int> channelToSfxID;

		static Mix_Music *musicFile;
		static QString musicLocation;
		static float musicMaxVolume;
		static float musicPlaySpeed;
		static int musicFadeInTime;
		static unsigned int musicFadeStartTicks;
		static bool musicRetainPitch;
		static bool freeMusic;
		static bool audioEnabled;
		static int outputFrequency;
		static Uint16 outputFormat;
		static int outputChannels;
};

#endif // AUDIOMANAGER_H
