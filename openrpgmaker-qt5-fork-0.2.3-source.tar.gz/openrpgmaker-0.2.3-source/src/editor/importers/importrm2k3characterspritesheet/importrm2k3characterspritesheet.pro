TEMPLATE = lib
TARGET = $$qtLibraryTarget(importrm2k3characterspritesheet)
DEPENDPATH += .
INCLUDEPATH += ../importerplugin \
               ../../
CONFIG += plugin debug
QT += widgets
contains(QT_ARCH, x86_64) {
	DESTDIR = ../../../../data/importers64
	DEFINES += ARCH_TYPE=\\\"64\\\"
} else {
	DESTDIR = ../../../../data/importers32
	DEFINES += ARCH_TYPE=\\\"32\\\"
}
LIBS =  ../libimporterplugin.a
PRE_TARGETDEPS +=  ../libimporterplugin.a

# Input
HEADERS += importrm2k3characterspritesheet.h
SOURCES += importrm2k3characterspritesheet.cpp

win32 {
	DEFINES -= UNICODE _UNICODE
}
