#include <QString>
#include <QMessageBox>
#include <QTimer>
#include <QtDebug>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include "audiomanager.h"
#include "projectdata.h"

QMap<unsigned int, AudioManager::SfxRuntime*> AudioManager::sfx = QMap<unsigned int, AudioManager::SfxRuntime*>();
QMap<unsigned int, AudioManager::SfxRuntime*>::iterator AudioManager::sfxIter = AudioManager::sfx.end();
QMap<int, unsigned int> AudioManager::channelToSfxID = QMap<int, unsigned int>();
QTimer *AudioManager::timer;
Mix_Music *AudioManager::musicFile = NULL;
QString AudioManager::musicLocation = QString();
float AudioManager::musicMaxVolume = 0;
float AudioManager::musicPlaySpeed = 1.0;
int AudioManager::musicFadeInTime = 0;
unsigned int AudioManager::musicFadeStartTicks = 0;
bool AudioManager::musicRetainPitch = true;
bool AudioManager::freeMusic = false;
bool AudioManager::audioEnabled = false;
int AudioManager::outputFrequency = 44100;
Uint16 AudioManager::outputFormat = MIX_DEFAULT_FORMAT;
int AudioManager::outputChannels = 2;

AudioManager::AudioManager() : QObject(0)
{
}

AudioManager::~AudioManager()
{
}

void AudioManager::initializeAudioManager()
{
	if (SDL_Init(SDL_INIT_AUDIO) < 0)
	{
		checkError(QString("initialize SDL audio subsystem: %1").arg(SDL_GetError()));
		audioEnabled = false;
		return;
	}

	int wantedFlags = MIX_INIT_OGG | MIX_INIT_MP3 | MIX_INIT_FLAC | MIX_INIT_MID;
	int gotFlags = Mix_Init(wantedFlags);
	if ((gotFlags & wantedFlags) != wantedFlags)
	{
		qWarning("AudioManager: some audio format decoders failed to initialize (%s)", Mix_GetError());
	}

	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
	{
		checkError(QString("open SDL_mixer audio device: %1").arg(Mix_GetError()));
		audioEnabled = false;
		Mix_Quit();
		SDL_QuitSubSystem(SDL_INIT_AUDIO);
		return;
	}

	if (!Mix_QuerySpec(&outputFrequency, &outputFormat, &outputChannels))
	{
		outputFrequency = 44100;
		outputFormat = MIX_DEFAULT_FORMAT;
		outputChannels = 2;
	}

	Mix_AllocateChannels(64);
	audioEnabled = true;

	timer = new QTimer(ProjectData::audioManager);
	QObject::connect(timer, SIGNAL(timeout()), ProjectData::audioManager, SLOT(updateSystem()));
	timer->start(100);
}

void AudioManager::shutdownAudioManager()
{
	if (audioEnabled)
	{
		timer->stop();
		QObject::disconnect(timer, SIGNAL(timeout()), ProjectData::audioManager, SLOT(updateSystem()));
		delete timer;

		stopAllSoundEffects();
		for (sfxIter = sfx.begin(); sfxIter != sfx.end(); ++sfxIter)
		{
			if (sfxIter.value())
			{
				if (sfxIter.value()->chunk)
					Mix_FreeChunk(sfxIter.value()->chunk);
				delete sfxIter.value();
			}
		}
		sfx.clear();
		channelToSfxID.clear();

		freeMusicFile();

		Mix_CloseAudio();
		Mix_Quit();
		SDL_QuitSubSystem(SDL_INIT_AUDIO);
		audioEnabled = false;
	}
}

unsigned int AudioManager::loadSoundEffect(QString location)
{
	unsigned int sfxID;
	bool foundOne = false;
	if (audioEnabled)
	{
		for (int i = 0; i < sfx.size() && !foundOne; ++i)
		{
			if (!sfx.contains(i))
			{
				sfxID = (unsigned int)i;
				foundOne = true;
			}
		}
		if (!foundOne)
			sfxID = sfx.size();

		Mix_Chunk *chunk = Mix_LoadWAV(location.toUtf8().data());
		if (!chunk)
		{
			checkError(QString("load sound effect \"%1\": %2").arg(location).arg(Mix_GetError()));
			return 0;
		}

		SfxRuntime *runtime = new SfxRuntime;
		runtime->chunk = chunk;
		runtime->location = location;
		runtime->channel = -1;
		runtime->speed = 1.0f;
		runtime->retainPitch = true;
		runtime->freeWhenFinished = false;
		runtime->samplesPlayed = 0;
		runtime->resamplePos = 0.0;

		sfx.insert(sfxID, runtime);
		return sfxID;
	}
	return 0;
}

void AudioManager::freeSoundEffect(unsigned int sfxID)
{
	if (audioEnabled)
	{
		sfxIter = sfx.find(sfxID);
		if (sfxIter != sfx.end())
		{
			SfxRuntime *runtime = sfxIter.value();
			if (runtime)
			{
				if (runtime->channel >= 0)
				{
					Mix_UnregisterEffect(runtime->channel, speedEffectCallback);
					Mix_HaltChannel(runtime->channel);
					channelToSfxID.remove(runtime->channel);
				}
				if (runtime->chunk)
					Mix_FreeChunk(runtime->chunk);
				delete runtime;
			}
			sfx.erase(sfxIter);
		}
	}
}

void AudioManager::playSoundEffect(unsigned int sfxID, float volume, float panning, float speed, bool retainPitch, int numLoops, bool freeWhenFinished)
{
	if (audioEnabled)
	{
		sfxIter = sfx.find(sfxID);
		if (sfxIter != sfx.end() && sfxIter.value() && sfxIter.value()->chunk)
		{
			SfxRuntime *runtime = sfxIter.value();

			int channel = Mix_PlayChannel(-1, runtime->chunk, numLoops);
			if (channel < 0)
			{
				checkError(QString("play sound effect %1: %2").arg(sfxID).arg(Mix_GetError()));
				return;
			}

			runtime->channel = channel;
			runtime->speed = (speed > 0.0f) ? speed : 1.0f;
			runtime->retainPitch = retainPitch;
			runtime->freeWhenFinished = freeWhenFinished;
			runtime->resamplePos = 0.0;
			channelToSfxID.insert(channel, sfxID);

			Mix_Volume(channel, (int)(qBound(0.0f, volume, 1.0f) * MIX_MAX_VOLUME));

			float p = panning < -1.0f ? -1.0f : (panning > 1.0f ? 1.0f : panning);
			Uint8 left  = (Uint8)(255.0f * (p <= 0.0f ? 1.0f : 1.0f - p));
			Uint8 right = (Uint8)(255.0f * (p >= 0.0f ? 1.0f : 1.0f + p));
			Mix_SetPanning(channel, left, right);

			if (runtime->speed != 1.0f)
				Mix_RegisterEffect(channel, speedEffectCallback, speedEffectDone, (void*)runtime);
		}
	}
}

void AudioManager::stopSoundEffect(unsigned int sfxID)
{
	if (audioEnabled)
	{
		sfxIter = sfx.find(sfxID);
		if (sfxIter != sfx.end() && sfxIter.value())
		{
			SfxRuntime *runtime = sfxIter.value();
			if (runtime->channel >= 0)
			{
				if (Mix_Playing(runtime->channel))
				{
					Mix_UnregisterEffect(runtime->channel, speedEffectCallback);
					Mix_HaltChannel(runtime->channel);
					emit ProjectData::audioManager->soundEffectStopped(sfxID);
				}
				channelToSfxID.remove(runtime->channel);
				runtime->channel = -1;
			}
			if (runtime->freeWhenFinished)
				freeSoundEffect(sfxID);
		}
	}
}

void AudioManager::loadMusicFile(QString location)
{
	if (audioEnabled)
	{
		if (musicFile)
			freeMusicFile();
		musicFile = Mix_LoadMUS(location.toUtf8().data());
		if (!musicFile)
		{
			checkError(QString("load music file \"%1\": %2").arg(location).arg(Mix_GetError()));
			return;
		}
		musicLocation = location;
	}
}

void AudioManager::freeMusicFile()
{
	if (audioEnabled)
	{
		if (Mix_PlayingMusic())
			Mix_HaltMusic();
		if (musicFile)
		{
			Mix_FreeMusic(musicFile);
			musicFile = NULL;
		}
		musicLocation = QString();
		freeMusic = false;
	}
}

void AudioManager::playMusic(int fadeInTime, float volume, float panning, float speed, bool retainPitch, bool freeWhenFinished)
{
	if (audioEnabled)
	{
		if (musicFile)
		{
			if (speed != 1.0f)
			{
				qWarning("AudioManager: music playback speed %.2f requested but not supported by the SDL2_mixer backend; playing at normal speed.", speed);
			}
			musicRetainPitch = retainPitch;
			musicPlaySpeed = 1.0f;
			musicMaxVolume = qBound(0.0f, volume, 1.0f);
			freeMusic = freeWhenFinished;

			int mixVolume = (int)(musicMaxVolume * MIX_MAX_VOLUME);

			float p = panning < -1.0f ? -1.0f : (panning > 1.0f ? 1.0f : panning);
			Uint8 left  = (Uint8)(255.0f * (p <= 0.0f ? 1.0f : 1.0f - p));
			Uint8 right = (Uint8)(255.0f * (p >= 0.0f ? 1.0f : 1.0f + p));
			Mix_SetPanning(MIX_CHANNEL_POST, left, right);

			if (fadeInTime != 0)
			{
				Mix_VolumeMusic(0);
				Mix_FadeInMusic(musicFile, 0, fadeInTime);
				musicFadeInTime = fadeInTime;
				musicFadeStartTicks = SDL_GetTicks();
			}
			else
			{
				Mix_VolumeMusic(mixVolume);
				Mix_PlayMusic(musicFile, 0);
				musicFadeInTime = 0;
			}
		}
	}
}

void AudioManager::stopMusic()
{
	if (audioEnabled)
	{
		if (Mix_PlayingMusic())
		{
			Mix_HaltMusic();
			emit ProjectData::audioManager->musicStopped();
		}
		if (freeMusic)
			freeMusicFile();
	}
}

void AudioManager::stopAllSoundEffects()
{
	QList<unsigned int> sfxIDs;
	for (sfxIter = sfx.begin(); sfxIter != sfx.end(); ++sfxIter)
	{
		if (sfxIter.value() && sfxIter.value()->channel >= 0)
			sfxIDs.append(sfxIter.key());
	}
	for (int i = 0; i < sfxIDs.size(); ++i)
		stopSoundEffect(sfxIDs[i]);
	sfxIDs.clear();
}

bool AudioManager::isSoundEffectPlaying(unsigned int sfxID)
{
	sfxIter = sfx.find(sfxID);
	if (sfxIter != sfx.end() && sfxIter.value() && sfxIter.value()->channel >= 0)
		return Mix_Playing(sfxIter.value()->channel) != 0;
	return false;
}

bool AudioManager::isSoundEffectPlaying()
{
	for (sfxIter = sfx.begin(); sfxIter != sfx.end(); ++sfxIter)
	{
		if (sfxIter.value() && sfxIter.value()->channel >= 0 && Mix_Playing(sfxIter.value()->channel))
			return true;
	}
	return false;
}

bool AudioManager::isMusicPlaying()
{
	return audioEnabled && Mix_PlayingMusic() != 0;
}

float AudioManager::getMusicPlaySpeed()
{
	return musicPlaySpeed;
}

unsigned int AudioManager::getMusicPosition()
{
	if (audioEnabled && isMusicPlaying())
	{
		double seconds = Mix_GetMusicPosition(musicFile);
		if (seconds >= 0.0)
			return (unsigned int)(seconds * 1000.0);
	}
	return 0;
}

unsigned int AudioManager::getSoundEffectLength(unsigned int sfxID)
{
	if (audioEnabled)
	{
		sfxIter = sfx.find(sfxID);
		if (sfxIter != sfx.end() && sfxIter.value() && sfxIter.value()->chunk)
		{
			Mix_Chunk *chunk = sfxIter.value()->chunk;
			int bytesPerSample = SDL_AUDIO_BITSIZE(outputFormat) / 8;
			int frameSize = bytesPerSample * outputChannels;
			if (frameSize > 0 && outputFrequency > 0)
				return (unsigned int)(((double)chunk->alen / frameSize) / outputFrequency * 1000.0);
		}
	}
	return 0;
}

unsigned int AudioManager::getMusicLength()
{
	if (audioEnabled && musicFile)
	{
		double seconds = Mix_MusicDuration(musicFile);
		if (seconds > 0.0)
			return (unsigned int)(seconds * 1000.0);
	}
	return 0;
}

bool AudioManager::isAudioEnabled()
{
	return audioEnabled;
}

void AudioManager::updateSystem()
{
	QList<unsigned int> finishedSfx;
	if (audioEnabled)
	{
		for (sfxIter = sfx.begin(); sfxIter != sfx.end(); ++sfxIter)
		{
			SfxRuntime *runtime = sfxIter.value();
			if (runtime && runtime->channel >= 0)
			{
				if (!Mix_Playing(runtime->channel))
				{
					channelToSfxID.remove(runtime->channel);
					runtime->channel = -1;
					emit soundEffectStopped(sfxIter.key());
					if (runtime->freeWhenFinished)
						finishedSfx.append(sfxIter.key());
				}
			}
		}
		for (int i = 0; i < finishedSfx.size(); ++i)
			freeSoundEffect(finishedSfx[i]);
		finishedSfx.clear();

		if (Mix_PlayingMusic())
		{
			if (musicFadeInTime != 0)
			{
				unsigned int elapsed = SDL_GetTicks() - musicFadeStartTicks;
				if ((int)elapsed >= musicFadeInTime)
				{
					Mix_VolumeMusic((int)(musicMaxVolume * MIX_MAX_VOLUME));
					musicFadeInTime = 0;
				}
			}
			emit musicPositionUpdated(getMusicPosition());
		}
		else if (freeMusic && musicFile)
		{
			freeMusicFile();
		}
	}
}

bool AudioManager::checkError(QString errorMessage)
{
	QMessageBox::critical(0, "Error", QString("Error: failed to %1").arg(errorMessage));
	return false;
}

void AudioManager::speedEffectCallback(int chan, void *stream, int len, void *udata)
{
	Q_UNUSED(chan);
	SfxRuntime *runtime = (SfxRuntime*)udata;
	if (!runtime || !runtime->chunk || runtime->speed == 1.0f)
		return;

	if ((outputFormat != AUDIO_S16LSB && outputFormat != AUDIO_S16MSB) || outputChannels < 1)
		return;

	int bytesPerFrame = 2 * outputChannels;
	int frameCount = len / bytesPerFrame;
	Sint16 *out = (Sint16*)stream;

	Uint8 *src = runtime->chunk->abuf;
	Uint32 srcFrames = runtime->chunk->alen / bytesPerFrame;
	if (srcFrames == 0)
		return;
	Sint16 *srcSamples = (Sint16*)src;

	for (int i = 0; i < frameCount; ++i)
	{
		Uint32 pos = (Uint32)runtime->resamplePos;
		if (pos >= srcFrames)
			break;

		for (int c = 0; c < outputChannels; ++c)
		{
			out[i * outputChannels + c] = srcSamples[pos * outputChannels + c];
		}
		runtime->resamplePos += runtime->speed;
	}
}

void AudioManager::speedEffectDone(int chan, void *udata)
{
	Q_UNUSED(chan);
	SfxRuntime *runtime = (SfxRuntime*)udata;
	if (runtime)
		runtime->resamplePos = 0.0;
}
