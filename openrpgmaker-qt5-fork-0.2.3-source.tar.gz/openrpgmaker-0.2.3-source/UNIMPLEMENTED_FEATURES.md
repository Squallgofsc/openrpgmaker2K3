# Fonctionnalités non implémentées ou incomplètes

Ce document recense tout ce qui, dans OpenRPGMaker 0.2.3, était prévu par
l'auteur d'origine mais n'a jamais été implémenté, ou qui reste inachevé.
Il est mis à jour à chaque nouvelle découverte au fil des tests fonctionnels
du fork.

**Dernière mise à jour :** revue systématique des 17 onglets de la fenêtre
Database (points 1 et 2 du plan de test).

---

## 1. Moteur de jeu (`src/engine`)

**Statut : jamais implémenté, à aucune version connue du projet.**

- Le dossier `src/engine` est **vide** dans l'archive source officielle
  0.2.3 elle-même (pas une erreur de notre archive).
- Confirmé explicitement par le fichier `INSTALL` d'origine : *"Engine -
  Linux: Not ready"* et *"Engine - Windows: Not ready"*.
- Confirmé par le changelog officiel de la version 0.2.1 sur SourceForge :
  le moteur ne faisait à l'époque que charger les données XML, sans aucun
  rendu.
- Confirmé par plusieurs avis d'utilisateurs sur la page SourceForge du
  projet (2014, 2016, 2025) : aucun n'a jamais pu "jouer" un jeu créé avec
  l'éditeur, faute de bouton "Play"/moteur d'exécution.

**Conséquence concrète :** l'éditeur permet de construire un jeu complet
(cartes, bases de données, ressources), mais il n'existe **aucun moyen de
le lancer ou de le tester réellement**, ni dans l'éditeur (pas de mode
"playtest"), ni en dehors (pas d'exécutable de jeu généré).

---

## 2. Onglet Database > Common Events

**Statut : jamais implémenté.**

Affiche uniquement le texte *"Not Yet Implemented"*, sans crash. Confirmé
lors de la revue systématique des onglets Database.

---

## 3. Onglet Database > Monster Groups

**Statut : jamais implémenté.**

Affiche uniquement le texte *"Not Yet Implemented"*, sans crash. Confirmé
lors de la revue systématique des onglets Database.

---

## 4. Conditionnelle OS pour la compilation multiplateforme — CORRIGÉE

**Statut : corrigée, sur la base de preuves tirées des builds officiels
d'origine (Linux/Windows/Mac, SourceForge, 0.2.3).**

Dans `src/editor/editor.pro`, la ligne suivante était codée en dur pour
Linux uniquement, avec un commentaire de l'auteur d'origine annonçant
l'intention de la rendre conditionnelle :
```
#Later these need to be moved into conditional based on OS
DEFINES += LIB_PREFIX=\"lib\" LIB_SUFFIX=\"so\"
```

**Méthode** : plutôt que de deviner les valeurs Windows/Mac, les trois
exécutables officiels publiés par l'auteur sur SourceForge (Linux
`.tar.bz2`, Windows `.exe`, Mac `.dmg`) ont été examinés directement
(extraction + inspection des chaînes binaires) pour observer les vrais
noms de fichiers de plugins utilisés en production :

| Plateforme | Preuve trouvée | Préfixe | Suffixe |
|---|---|---|---|
| Linux | `libimportrm2k3background.so` | `lib` | `so` |
| Windows | `importrm2k3background.dll` (dans l'installeur BitRock) | *(vide)* | `dll` |
| Mac | `libfmodex.dylib` (convention Mac standard, frameworks Qt4) | `lib` | `dylib` |

**Découverte annexe** : les dossiers `data/importers32` et
`data/importers64` du build Mac officiel sont **vides** — l'auteur
d'origine n'a jamais livré de plugins d'import fonctionnels pour Mac, dès
la sortie de la 0.2.3. La fonctionnalité "Import External Data" était donc
déjà cassée sur Mac dans la version officielle, indépendamment de ce
fork.

**Correctif appliqué**, avec les scopes qmake natifs `win32`/`macx` :
```
win32 {
	DEFINES += LIB_PREFIX=\"\" LIB_SUFFIX=\"dll\"
} else:macx {
	DEFINES += LIB_PREFIX=\"lib\" LIB_SUFFIX=\"dylib\"
} else {
	DEFINES += LIB_PREFIX=\"lib\" LIB_SUFFIX=\"so\"
}
```
Testé et validé sur Linux (seule plateforme disponible pour compiler ici)
: `qmake` résout correctement vers `lib`/`so` via la branche `else`,
compilation complète réussie sans régression. Les valeurs Windows/Mac
restent non testées à la compilation réelle (aucun environnement
Windows/Mac disponible ici), mais reposent sur des preuves directes tirées
des binaires officiels plutôt que sur une supposition.

**Important — limite connue** : corriger cette conditionnelle rend le
code source correctement préparé pour Windows/Mac, mais ne suffit pas à
produire des exécutables Windows/Mac depuis cet environnement (Linux
uniquement). Windows nécessiterait Qt5 et SDL2 compilés pour cible MinGW
(non disponibles en paquets ici) ; Mac nécessiterait le SDK Apple, dont la
licence interdit l'usage hors matériel Apple. Des builds réels pour ces
plateformes nécessitent une compilation sur une vraie machine Windows/Mac.

---

## 5. Import externe : échecs silencieux sans retour utilisateur

**Statut : lacune UX, jamais traitée par l'auteur d'origine.**

Testé lors de la revue systématique des 7 plugins d'import RM2K3 (point 3
du plan de test). Trois plugins peuvent échouer **complètement
silencieusement** — aucun message d'erreur, aucun avertissement — quand
l'image fournie ne correspond pas exactement au format/dimensions RM2K3
classique attendu :

- **Monster** : bug de code confirmé — `importrm2k3monster.cpp:62` appelle
  `QImage::pixelIndex()` sans vérifier que l'image source est bien en mode
  palette (`depth() <= 8`), contrairement au helper partagé
  `ImporterPlugin::drawImage()` qui fait cette vérification correctement.
  Sur une image en vraie couleur (24/32-bit), `pixelIndex()` échoue et
  retourne toujours 0, ce qui fait que tous les pixels sont traités comme
  transparents ; l'image résultante est alors jugée "vide" par
  `isImageEmpty()` et la sauvegarde est silencieusement sautée. **Confirmé
  fonctionnel avec une image à palette réelle** (test avec PNG 8-bit
  indexé réussi).
- **Battle Character** et **Face Set** : échec silencieux constaté avec
  une image de test ne respectant pas les dimensions/décalages fixes
  attendus (le découpage par rectangles codés en dur lit alors des zones
  hors limites ou non pertinentes, produisant une image jugée "vide").

Dans tous les cas, l'utilisateur ne reçoit **aucune indication** que
l'import a échoué — le dialogue se ferme normalement comme en cas de
succès. À corriger : (a) le bug `pixelIndex()` de Monster, et (b) ajouter
un message d'erreur explicite quand `isImageEmpty()` bloque une
sauvegarde, pour tous les plugins concernés.

---

## 6. Aperçu musical (Listen to Music) : affichage de durée incohérent avec Play Speed ≠ 100% — CORRIGÉ

**Statut : bug corrigé et validé.**

Testé lors du point 4 (audio en conditions réelles), via `Tools > Listen
to Music`. Quand le curseur "Play Speed" est modifié (ex. 200%), le champ
"Music Length" recalcule la durée totale affichée en fonction de la
vitesse demandée (ex. 3.0s → 1.5s), mais **la lecture réelle continue à
vitesse normale** — cohérent avec la limitation déjà documentée du nouveau
`AudioManager` (SDL2_mixer ne permet pas de rééchantillonnage temps réel
d'un flux musical streamé, contrairement aux effets sonores). Résultat :
l'affichage de la position se fige une fois qu'il atteint le "Total"
(erroné, trop court), alors que la lecture continue probablement en
arrière-plan (bouton Stop resté actif après le blocage de l'affichage).

**Confirmé sans impact sur le cas d'usage par défaut** : à vitesse 100%
(le réglage par défaut, donc le plus probable en usage normal), position
et durée totale restent parfaitement synchronisées et exactes tout au
long de la lecture.

À corriger : soit désactiver/griser le curseur "Play Speed" pour la
musique tant que le rééchantillonnage réel n'est pas implémenté, soit
faire en sorte que l'affichage de durée reflète la vitesse réellement
appliquée (1x) plutôt que la vitesse demandée mais ignorée.

**Correctif appliqué** (`musicbrowser.cpp`) : trois emplacements
divisaient à tort la durée/position par la vitesse *demandée* par
l'utilisateur (`sldrSpeed`), alors que `AudioManager` ignore délibérément
cette vitesse pour la musique (limitation SDL2_mixer déjà documentée) et
ne l'applique jamais réellement. Un bug de double-division existait même
dans le calcul de position (`musicPositionUpdated()`). Toutes les
divisions par `musicPlaySpeed` ont été retirées ; l'affichage utilise
maintenant directement les valeurs réelles renvoyées par `AudioManager`
(`getMusicLength()`/`getMusicPosition()`), et `musicPlaySpeed` est lu
après coup via `AudioManager::getMusicPlaySpeed()` (qui reflète la
vitesse réellement appliquée) plutôt que la valeur brute du curseur.
Testé et validé : à 200%, l'affichage montre maintenant la vraie durée
(3.0s) et la position progresse normalement jusqu'au bout, sans blocage.

---

## 7. Menu Project > Create Game Disk

**Statut : jamais implémenté.**

Testé lors du point 5 (Play Test / génération de jeu). Le clic ne produit
**aucun retour visuel et aucun fichier sur disque** — action totalement
silencieuse. Confirmé dans le code source :
`MainWindow::on_aCreateGameDisk_triggered()` ne contient que
`TODO("Implement function");`, une macro qui ne fait littéralement rien à
l'exécution. Cohérent avec le constat déjà fait sur le moteur de jeu
(point 1) : sans moteur, il n'y a de toute façon rien de "jouable" à
empaqueter dans un disque de jeu.

---

## 8. Fonctionnalités des générations RPG Maker plus récentes (VX, VX Ace, MV, MZ)

**Statut : piste lointaine, non engagée — recommandation de principe
seulement, à réévaluer le moment venu.**

Question posée par Sébastien : est-il envisageable d'intégrer à ce fork
les fonctionnalités apportées par les versions de RPG Maker sorties après
XP (VX, VX Ace, MV, MZ) ?

**Constat technique** : l'architecture actuelle d'OpenRPGMaker est
structurellement pensée pour RM2000/2003 jusque dans des détails très
concrets rencontrés pendant les tests de ce fork — taille de tuiles fixe
(16×16), rectangles de découpage codés en dur dans les importeurs,
constantes comme `NUM_PHASES=24`, absence totale de moteur de script. Les
générations suivantes changent ces conventions en profondeur (32×32 puis
48×48 pour les tuiles, moteurs de script Ruby puis JavaScript,
organisation des feuilles de ressources en catégories séparées — déjà
observé concrètement avec le pack de tuiles Time Fantasy testé au point
3). Faire tenir toutes ces générations dans un seul projet reviendrait à
une refonte architecturale complète, pas à un ajout de fonctionnalités.

**Recommandation** : plutôt que d'étendre ce projet indéfiniment, envisager
à terme deux projets distincts et séparés, utilisant ce fork comme base
de départ (réutilisation du pipeline de build, du système audio
SDL2_mixer, des patterns d'interface) mais avec un modèle de données et
des importeurs largement reconstruits pour chaque génération :
- Un projet reprenant les fonctionnalités RPG Maker VX / VX Ace
- Un projet reprenant les fonctionnalités RPG Maker MV / MZ

Cette séparation correspond à la réalité du domaine (ce sont déjà des
produits distincts dans la série RPG Maker elle-même), limite les risques
de régression sur le périmètre RM2K/2K3 tout juste stabilisé, et permet
à d'éventuels contributeurs de se concentrer sur la génération qui les
intéresse.

**Décidé avec Sébastien** : possibilité lointaine, pas un choix immédiat.
À reprendre une fois la phase actuelle (correction + fork GitHub)
terminée.

---

## 9. Traduction française de l'interface + sélecteur de langue

**Statut : faisable, cadré, non engagé — piste pour la phase
d'amélioration.**

Question posée par Sébastien : l'interface n'existe qu'en anglais,
est-il possible d'ajouter une traduction française complète avec un
sélecteur de langue dans un menu Options ?

**Constat technique favorable** : la quasi-totalité de l'interface est
construite via des fichiers `.ui` (Qt Designer), et le code généré par
Qt (`ui_*.h`) enveloppe déjà systématiquement chaque texte dans
`QCoreApplication::translate("Contexte", "Texte", nullptr)` — le
mécanisme d'internationalisation standard de Qt. Le gros du travail
mécanique (rendre chaque chaîne traduisible) est donc déjà fait, sans
qu'aucune modification n'ait été nécessaire pour ce fork.

**Reste à faire, sans risque architectural identifié :**
1. Extraire les chaînes traduisibles (`lupdate`)
2. Traduire vers le français (fichier `.ts`)
3. Compiler en `.qm` (`lrelease`)
4. Charger la traduction au démarrage via `QTranslator`, selon la langue
   choisie
5. Créer un menu/dialogue "Options" avec sélecteur de langue — n'existe
   pas encore dans l'éditeur (à ne pas confondre avec l'onglet "System"
   de la Database, qui concerne les données du jeu en cours de création,
   pas les préférences de l'éditeur lui-même)

À la différence du point 8 (générations RPG Maker récentes), ce chantier
est bien plus prévisible : pas de refonte de modèle de données, travail
mécanique et localisé.

---

## Notes générales

- Le `README`, `TODO` et `NEWS` d'origine sont essentiellement vides
  (sections sans contenu) — l'auteur n'a jamais documenté formellement ses
  intentions au-delà de ce qui précède.
- Cette liste ne couvre que ce qui a été exploré jusqu'ici (création de
  projet/carte, et les 17 onglets de la base de données). Elle sera
  complétée au fur et à mesure des tests des points suivants (import de
  données externes RM2K3, audio en conditions réelles, etc.).
